export const environment = {
    LABTV_API_BASE_URL: "https://api.themoviedb.org/3/movie/",
    LABTV_API_KEY: "406d7ce80a569d7381271d932f093c4a"
};
