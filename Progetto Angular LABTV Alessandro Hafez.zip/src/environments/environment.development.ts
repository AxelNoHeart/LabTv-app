export const environment = {
    USER_API_BASE_URL: "http://localhost:3000/",
    LABTV_API_BASE_URL: "https://api.themoviedb.org/3/",
    LABTV_API_KEY: "406d7ce80a569d7381271d932f093c4a"
};
